package com.gmiskos.stockservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
